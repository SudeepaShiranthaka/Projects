<?php
	include_once 'config.php';
	
	if(isset($_POST['btn-send']))
	{
		$name = $_POST['fname'];
		$email = $_POST['email'];
		$message = $_POST['subject'];
		
		$sql = "INSERT INTO contactus (username,email,message) VALUES('$name','$email','$message')";
		if(mysqli_query($conn, $sql))
		{
			//echo
			header("Location:index.html");
		}
		else
		{
			echo"<script>alert('ERROR:could not able to execute $sql. ')</script>";
		}
		//close connection
		mysqli_close($conn);
	}	
?> 