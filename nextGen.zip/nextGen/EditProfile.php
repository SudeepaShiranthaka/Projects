<?php
include_once "config.php";
?>

<?php
SESSION_START();
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
	$_SESSION['Login'] =$_POST['username'];
	$_SESSION['Password'] =$_POST['psw'];
	header("Location:loginvalidate.php");
}
?>
<?php 
$first_name =$_POST['first_name'];
$last_name =$_POST['last_name'];
$email =$_POST['email'];
$address = $_POST['address'];
$password =$_POST['password'];
$user_name =$_POST['user_name'];
$phone=$_POST['phone'];

$sql = "INSERT INTO customer(First_Name,Last_Name,Email,Address,Password,User_Name,Phone) VALUES('$first_name','$last_name','$email','$address','$password','$user_name','$phone')";


if(mysqli_query($conn,$sql)){
    echo "<script type='text/javascript'>alert('Updated Sucessfully!'); window.location.href='index.html';</script>";

}
else{
    echo "<script type='text/javascript'>alert('Update Failed!'); window.location.href='sign_in.html';</script>";
}

mysqli_close($conn);
?>
