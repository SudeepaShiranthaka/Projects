<?php
	include_once 'config.php';
?>
<?php 
$first_name =$_POST['first_name'];
$last_name =$_POST['last_name'];
$email =$_POST['email'];
$address = $_POST['address'];
$password =$_POST['password'];
$user_name =$_POST['user_name'];
$phone=$_POST['phone'];

//$errors=array();
//checking email address
/*if(!is_email($_POST['email'])){
	$errors[] ='Email address is invalid!';
}

$query ="SELECT * FROM customer where Email='{$email}' LIMIT 1";
$result_set = mysqli_query($conn,$query);

if($result_set){
	if(mysqli_num_rows($result_set)==1){
		$errors[] = 'Email address already exist!';
	}
}*/



$sql = "INSERT INTO customer(First_Name,Last_Name,Email,Address,Password,User_Name,Phone) VALUES('$first_name','$last_name','$email','$address','$password','$user_name','$phone')";

if(mysqli_query($conn,$sql)){
    echo "<script type='text/javascript'>alert('Registed Sucessfully!'); window.location.href='index.html';</script>";

}
else{
    echo "<script type='text/javascript'>alert('Registration Failed!'); window.location.href='sign_in.html';</script>";
}

mysqli_close($conn);
?>