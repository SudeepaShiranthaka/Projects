function enableButton()
{
	
	if(document.getElementById("check").checked)
	{			
		document.getElementById("submit").disabled = false;
	}
	else
	{
		document.getElementById("submit").disabled = true;
	}
}
