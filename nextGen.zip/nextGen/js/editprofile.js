function saveChanges() {
  alert("Profile updated successfully !");
}

function validate() {
    var a = document.getElementById("pswrd").value;
    var b = document.getElementById("rpswrd").value;
    if (a == b) {
        alert("Matched");
        return true;
    }
    else {
        alert("Password and Re-enter Password do not match!");
        return false;
    }
}

function subenable() {
    if (document.getElementById("acept").checked) {
        document.getElementById("sbt").disabled = false;
    }
    else {
        document.getElementById("sbt").disabled = true;
    }

function myFunction() {
  var x = document.getElementById("myInput");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}