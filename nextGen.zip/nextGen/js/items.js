function loadData(data)
{
    if(data == "btn1")
    {
      alert("item has been added to card");
    }
    else if(data == "btn2")
    {
        alert("item has been removed to card");
    }
}