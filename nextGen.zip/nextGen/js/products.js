
	function myFunction() {
		var category = arguments[0];
		switch (category)
		{
//keyboard
			case 'keyboard':
				var keyboard = document.getElementsByName("keyboard");
				for(var i=0;i<keyboard.length;i++)
				{
					keyboard[i].style.display = "block";
				}
				
				var mouse = document.getElementsByName("mouse");
				for(var i=0;i<mouse.length;i++)
				{
					mouse[i].style.display = "none";
				}
				
				var monitor = document.getElementsByName("monitor");
				for(var i=0;i<monitor.length;i++)
				{
					monitor[i].style.display = "none";
				}
				
				var vga = document.getElementsByName("vga");
				for(var i=0;i<vga.length;i++)
				{
					vga[i].style.display = "none";
				}
				
				var hard = document.getElementsByName("hard");
				for(var i=0;i<hard.length;i++)
				{
					hard[i].style.display = "none";
				}
				break;
//mouse				
			case 'mouse':					
				var keyboard = document.getElementsByName("keyboard");
				for(var i=0;i<keyboard.length;i++)
				{
					keyboard[i].style.display = "none";
				}
				
				var mouse = document.getElementsByName("mouse");
				for(var i=0;i<mouse.length;i++)
				{
					mouse[i].style.display = "block";
				}
				
				var monitor = document.getElementsByName("monitor");
				for(var i=0;i<monitor.length;i++)
				{
					monitor[i].style.display = "none";
				}
				
				var vga = document.getElementsByName("vga");
				for(var i=0;i<vga.length;i++)
				{
					vga[i].style.display = "none";
				}
				
				var hard = document.getElementsByName("hard");
				for(var i=0;i<hard.length;i++)
				{
					hard[i].style.display = "none";
				}
				break;
//vga				
			case 'vga':		
				var keyboard = document.getElementsByName("keyboard");
				for(var i=0;i<keyboard.length;i++)
				{
					keyboard[i].style.display = "none";
				}
				
				var mouse = document.getElementsByName("mouse");
				for(var i=0;i<mouse.length;i++)
				{
					mouse[i].style.display = "none";
				}
				
				var monitor = document.getElementsByName("monitor");
				for(var i=0;i<monitor.length;i++)
				{
					monitor[i].style.display = "none";
				}
				
				var vga = document.getElementsByName("vga");
				for(var i=0;i<vga.length;i++)
				{
					vga[i].style.display = "block";
				}
				
				var hard = document.getElementsByName("hard");
				for(var i=0;i<hard.length;i++)
				{
					hard[i].style.display = "none";
				}
				break;
//monitor
			case 'monitor':			
				var keyboard = document.getElementsByName("keyboard");
				for(var i=0;i<keyboard.length;i++)
				{
					keyboard[i].style.display = "none";
				}
				
				var mouse = document.getElementsByName("mouse");
				for(var i=0;i<mouse.length;i++)
				{
					mouse[i].style.display = "none";
				}
				
				var monitor = document.getElementsByName("monitor");
				for(var i=0;i<monitor.length;i++)
				{
					monitor[i].style.display = "block";
				}
				
				var vga = document.getElementsByName("vga");
				for(var i=0;i<vga.length;i++)
				{
					vga[i].style.display = "none";
				}
				
				var hard = document.getElementsByName("hard");
				for(var i=0;i<hard.length;i++)
				{
					hard[i].style.display = "none";
				}
				break;
//hard
			case 'hard':
				var keyboard = document.getElementsByName("keyboard");
				for(var i=0;i<keyboard.length;i++)
				{
					keyboard[i].style.display = "none";
				}
				
				var mouse = document.getElementsByName("mouse");
				for(var i=0;i<mouse.length;i++)
				{
					mouse[i].style.display = "none";
				}
				
				var monitor = document.getElementsByName("monitor");
				for(var i=0;i<monitor.length;i++)
				{
					monitor[i].style.display = "none";
				}
				
				var vga = document.getElementsByName("vga");
				for(var i=0;i<vga.length;i++)
				{
					vga[i].style.display = "none";
				}
				
				var hard = document.getElementsByName("hard");
				for(var i=0;i<hard.length;i++)
				{
					hard[i].style.display = "block";
				}
				break;

//all		
			default:
				var keyboard = document.getElementsByName("keyboard");
				for(var i=0;i<keyboard.length;i++)
				{
					keyboard[i].style.display = "block";
				}
				
				var mouse = document.getElementsByName("mouse");
				for(var i=0;i<mouse.length;i++)
				{
					mouse[i].style.display = "block";
				}
				
				var monitor = document.getElementsByName("monitor");
				for(var i=0;i<monitor.length;i++)
				{
					monitor[i].style.display = "block";
				}
				
				var vga = document.getElementsByName("vga");
				for(var i=0;i<vga.length;i++)
				{
					vga[i].style.display = "block";
				}
				
				var hard = document.getElementsByName("hard");
				for(var i=0;i<hard.length;i++)
				{
					hard[i].style.display = "block";
				}
				break;				
			
		
		}   
	}
