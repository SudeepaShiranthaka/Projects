
function validate() {
    var a = document.getElementById("pswrd").value;
    var b = document.getElementById("rpswrd").value;
    if (a == b) {
        alert("Matched");
        return true;
    }
    else {
        alert("Password and Re-enter Password do not match!");
        return false;
    }
}
/*    if (document.getElementById("acept").checked) {
        document.getElementById("sbt").disabled = false;
    }
    else {
        document.getElementById("sbt").disabled = true;
    }*/

function subenable() {
    if (document.getElementById("acept").checked) {
        document.getElementById("sbt").disabled = false;
    }
    else {
        document.getElementById("sbt").disabled = true;
    }
}