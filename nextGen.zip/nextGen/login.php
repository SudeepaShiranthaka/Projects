<?php
	include_once 'config.php';
?>

<?php
SESSION_START();
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
	$_SESSION['Login'] =$_POST['username'];
	$_SESSION['Password'] =$_POST['psw'];
	header("Location:loginvalidate.php");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Next GEN</title>
    <link rel="stylesheet" type="text/css" href="styles/styles1.css">
    <link rel="stylesheet" type="text/css" href="styles/slideshow.css">
    <link rel="stylesheet" type="text/css" href="styles/index.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="styles/login.css">
    <script src="js/login.js"></script>

</head>
<body>
    <header>
        <ul class="logos">
            <li class="left_upper_logo">
                <a href="index.html">
                    <img class="logo" src="images/logo.jpg" alt="home">
                </a>
            </li>
            <li class="right_upper_logo"><a href="#">Sign In</a></li>
            <li class="right_upper_logo">
                <a href="Profile.html">
                    <i class="fa fa-user-circle-o" style="font-size:80px"></i>
                </a>
            </li>
            <li class="right_upper_logo">
                <a href="cart.html">
                    <i class="fa fa-shopping-cart" style="font-size:40px"></i>
                </a>
            </li>
        </ul>
        <br><br><br><br><br><br><br><br><br>
        <ul class="upper_bar">
            <li class="upper"><a class="up" href="upper_bar/about_us.html">About Us</a></li>
            <li class="upper"><a class="up" href="">Comments</a></li>
            <li class="upper"><a class="up" href="FAQ.html">FAQ</a></li>
            <li class="upper"><a class="up" href="privacy_policy.html">Priacy Policy</a></li>
        </ul>
    </header>
    <hr>
    <div>
        <nav>
            <ul class="no1">
                <li class="no1"><a class="middle" href="index.html">Home</a></li>
                <li class="no1"><a class="middle" href="Profile.html">Profile</a></li>
                <li class="no1"><a class="middle" href="Product.html">Product</a></li>
                <li class="no1"><a class="middle" href="Contact_us.html">Contact Us</a></li>
                <form class="search-from">
                    <input type="text" placeholder="search">
                    <button class="search">search</button>
                </form>

            </ul>

        </nav>
    </div>
    <div class="container">
	<?php 
		if(isset($_GET['logout'])){
			echo '<p class="info">You Have Sucessfully Logout!</p>';
		}
	//class="info" => index.css
	
	?>



        <form action="" Method="POST">
            <div class="row">
                <h2 style="text-align:center; color:lightsteelblue">Welcome to NextGen! Please login.</h2>
                <div class="vl">
                    <span class="vl-innertext">or</span>
                </div>

                <div class="col">
                    <a href="https://www.facebook.com" class="fb btn">
                        <i class="fa fa-facebook fa-fw"></i> Login with Facebook
                    </a>
                    <a href="https://twitter.com/login/" class="twitter btn">
                        <i class="fa fa-twitter fa-fw"></i> Login with Twitter
                    </a>
                    <a href="https://www.gmail.com" class="google btn">
                        <i class="fa fa-google fa-fw">
                        </i> Login with Google+
                    </a>
                </div>

                <div class="col">
                    <div class="hide-md-lg">
                        <p>Or sign in manually:</p>
                    </div>

                    <input type="text" name="username" placeholder="Username" id="usrname" required>
                    <input type="password" id="psw" name="psw" placeholder="Password" required>
                    <input type="submit" value="Login">
                    <div id="message">
                        <h3>Password must contain the following:</h3>
                        <p id="letter" class="invalid">A <b>lowercase</b> letter</p>
                        <p id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
                        <p id="number" class="invalid">A <b>number</b></p>
                        <p id="length" class="invalid">Minimum <b>8 characters</b></p>
                    </div>
                </div>

            </div>
        </form>
    </div>

    <div class="bottom-container">
        <div class="row">
            <div class="col">
                <a href="sign_in.html" style="color:white" class="btn">Sign up</a>
            </div>
            <div class="col">
                <a href="#" style="color:white" class="btn">Forgot password?</a>
            </div>
        </div>
    </div>
    <hr>
    <div>
        <footer>
            <ul>
                <li class="footer_icons1"><i class="fa fa-cc-paypal" style="font-size:40px"></i></li>
                <li class="footer_icons1"><i class="fa fa-cc-mastercard" style="font-size:40px"></i></li>
                <li class="footer_icons1"><i class="fa fa-cc-amex" style="font-size:40px"></i></li>
                <li class="footer_icons1"><i class="fa fa-cc-visa" style="font-size:40px"></i></li>
                <li class="footer_icons1"><h4 class="footer_text">Copyright2019 NextGen(pvt)Ltd.</h4></li>
            </ul>
           <ul>
               <li class="footer_icons2"><i class="fa fa-facebook-square" style="font-size:40px"></i></li>
               <li class="footer_icons2"><i class="fa fa-instagram" style="font-size:40px"></i></li>
               <li class="footer_icons2"><i class="fa fa-twitter" style="font-size:40px"></i></li>
           </ul>
                <p class="footer_para">Contact Us: <br> +94772341235 <br> Email Us: <br> NextGen@gmail.com</p>
    
    
        </footer>
    </div>


</body>
</html>