<?php

include_once "config.php";

session_start();

$user=$_SESSION['Login'];
$pw=$_SESSION['Password'];


$sql="SELECT * from customer where user_name='$user'AND password='$pw'";
$result=mysqli_query($conn,$sql);
if ($result->num_rows > 0)
{
	echo "<script type='text/javascript'>alert('login Sucessfully!'); window.location.href='users.php';</script>";
}
else
{
	echo "<script type='text/javascript'>alert('login failed!'); window.location.href='login.php';</script>";
}


		/*if ($result->num_rows > 0)
		{
			while ($row=$result->fetch_assoc())
			{
				echo "Login details validated";	
				header("Location:users.php");
			}
		}
		
		else
		{
			echo "password is wrong";
			header("Location:login.php");
			
		}*/
		
	

/*else
{	
	session_destroy();
	header("Location:login.php");
}*/
$conn->close();

?>
