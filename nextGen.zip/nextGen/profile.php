<?php
include_once "config.php";
session_start();
?>

<!DOCTYPE html>

<html>
<head>
    <title>Next GEN</title>
    <link rel="stylesheet" type="text/css" href="styles/styles1.css">
    <link rel="stylesheet" type="text/css" href="styles/profile.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="js/profile.js"></script>
</head>
</html>
<body>
    <header>
        <ul class="logos">
            <li class="left_upper_logo">
                <a href="index.html">
                    <img class="logo" src="images/logo.jpg" alt="home">
                </a>
            </li>
            <li class="right_upper_logo"><p style=color:white>Welcome <?php echo $_SESSION['Login']; ?>!</p><a href="logout.php">Log Out</a></li>
            <li class="right_upper_logo">
                <a href="Profile.html">
                    <i class="fa fa-user-circle-o" style="font-size:80px"></i>
                </a>
            </li>
            <li class="right_upper_logo">
                <a href="cart.html">
                    <i class="fa fa-shopping-cart" style="font-size:40px"></i>
                </a>
            </li>
        </ul>
        <br><br><br><br><br><br><br><br><br>
        <ul class="upper_bar">
            <li class="upper"><a class="up" href="about.html">About Us</a></li>
            <li class="upper"><a class="up" href="">Comments</a></li>
            <li class="upper"><a class="up" href="FAQ.html">FAQ</a></li>
            <li class="upper"><a class="up" href="privacy_policy.html">Priacy Policy</a></li>
        </ul>
    </header>
    <hr>
    <div>
        <nav>
            <ul class="no1">
                <li class="no1"><a class="middle" href="index.html">Home</a></li>
                <li class="no1"><a class="middle" href="#">Profile</a></li>
                <li class="no1"><a class="middle" href="Product.html">Product</a></li>
                <li class="no1"><a class="middle" href="Contact_us.html">Contact Us</a></li>
                <form class="search-from">
                    <input type="text" placeholder="search">
                    <button class="btn1">search</button>
                </form>
            </ul>
        </nav>
    </div>
    <div>
        <br>
        <center>
            <h1 ></><font font-weight:normal color=#25c84f> Profile Details</font></h1>
            <br />
            <h2 class="hh"> <font color="white"></color></font></h2>
            <table>
                <img class="profimg" style="margin-left:25px;" src="images/prof.jpg" width="200" height="200">

            </table>
        </center>
        <br>
        <center>
            <div class="develop">
                <div class="row" style="width:1000px;">

                    <div class="column" style="color:white;">
                        <form action="profile.php" method="get" onsubmit="return validate()">
                          
                            <input class="txtbox" type="text" id="id" hidden />
                            First Name:
                            <br />
                            <input class="txtbox" type="text" id="fname"  pattern="[0-9a-zA-Z]+" readonly />
                            <br /><br />
                            Email Address:
                            <br />
                            <input class="txtbox" type="text" id="email"  pattern="[a-zA-Z0-9%_+-]+@[a-zA-Z]+/.[a-zA-Z]{2,3}"  readonly />
                            <br /><br />
                            Home Address:
                            <br />
                            <input class="txtarea" type="text" rows="5" cols="30" id="adrs"  readonly>
                            <br /><br /><br />
                        </form>
                    </div>
                    <div class=" column" style="color:white;">
                        <form action="index.html" method="get" onsubmit="return validate()">
                            Last Name:
                            <br />
                            <input class="txtbox" type="text" id="lname"  pattern="[0-9a-zA-Z]+"  readonly />
                            <br /><br />
                            Phone Number:
                            <br />
                            <input class="txtbox" type="text" id="pnum"  pattern="[0-9]{10}"  readonly />
                            <br /><br />
                        

                        </form>

                    </div>

                </div>
            </div>
        </center>
        <br>
        <br>
        <fieldset>
            <font color="white">
                <h2>Password </h2>
                <p>
                    Password: <input class="txtbox" type="password" value="Testpswd" id="myInput"><br><br>
                    <input type="checkbox" onclick="myFunction()">Show Password
                </p>
        </fieldset>
        <br>
        <input class ="btnedit" type="button" value="Edit Details" onclick="window.location.href='EditProfile.html'" />
        <br>
        <br />
        <hr>
        <footer>
            <ul>
                <li class="footer_icons1"><i class="fa fa-cc-paypal" style="font-size:40px"></i></li>
                <li class="footer_icons1"><i class="fa fa-cc-mastercard" style="font-size:40px"></i></li>
                <li class="footer_icons1"><i class="fa fa-cc-amex" style="font-size:40px"></i></li>
                <li class="footer_icons1"><i class="fa fa-cc-visa" style="font-size:40px"></i></li>
                <li class="footer_icons1"><h4 class="footer_text">Copyright2019 NextGen(pvt)Ltd.</h4></li>
            </ul>
           <ul>
               <li class="footer_icons2"><i class="fa fa-facebook-square" style="font-size:40px"></i></li>
               <li class="footer_icons2"><i class="fa fa-instagram" style="font-size:40px"></i></li>
               <li class="footer_icons2"><i class="fa fa-twitter" style="font-size:40px"></i></li>
           </ul>
                <p class="footer_para">Contact Us: <br> +94772341235 <br> Email Us: <br> NextGen@gmail.com</p>
    
    
        </footer>
</body>


<?php
	include_once 'config_admin.php';
?>

<?php
	$recordId = $_GET['ID'];
	$sql = "SELECT * FROM customer WHERE User_ID = $recordId";
	$result = $conn->query($sql);
	if($result->num_rows > 0)
	{
		while($row = $result->fetch_assoc())
		{	
            $id  = $row["User_ID"];		
			$fname = $row["First_Name"];
			$lname = $row["Last_Name"];
			$email = $row["Email"];
			$add = $row["Address"];
            $phe = $row["Phone"];
		}
	}
	else
	{
		echo "0 results";
    }    
?>
    <form method = "post" action = "profile.php">
        <input type = 'hidden' id = "id" value =<?php echo $id ?> />
		<input type = 'text' id = "fname" value =<?php echo $fname ?> />
		<input type = 'text' id = "email" value =<?php echo $email ?> />
		<input type = 'text' id = "adrs" value =<?php echo $add?> />
        <input type = 'text' id = "lname" value =<?php echo $lname ?> />
        <input type = 'text' id = "pnum" value =<?php echo $phe ?> />
		
	</form>