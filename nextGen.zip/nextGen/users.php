<?php

include_once "config.php";
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Next GEN</title>
        <link rel="stylesheet" type="text/css" href="styles/styles1.css">
        <link rel="stylesheet" type="text/css" href="styles/slideshow.css">
        <link rel="stylesheet" type="text/css" href="styles/index.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://fontawesome.com/icons/facebook-square?style=brands">
        
    </head>
<body>
    <header>
        <ul class="logos">
            <li class="left_upper_logo"><a href="index.html">
            <img class="logo" src="images/logo.jpg" alt="home">
			</a></li>
            <li class="right_upper_logo"><p style=color:white>Welcome <?php echo $_SESSION['Login']; ?>!</p><a href="logout.php">Log Out</a></li>
            <li class="right_upper_logo"><a href="Profile.html">
            <i class="fa fa-user-circle-o" style="font-size:80px"></i>   
            </a></li>
            <li class="right_upper_logo"><a href="cart.html">
            <i class="fa fa-shopping-cart" style="font-size:40px"></i>
            </a></li>
        </ul>
    <br><br><br><br><br><br><br><br><br>
        <ul class="upper_bar">
            <li class="upper"><a class="up" href="about.html">About Us</a></li>
            <li class="upper"><a class="up" href="">Comments</a></li>
            <li class="upper"><a class="up" href="FAQ.html">FAQ</a></li>
            <li class="upper"><a class="up" href="privacy_policy.html">Privacy Policy</a></li>
        </ul>
        </header>
    <hr>
    <div>
        <nav>
            <ul class="no1">
                <li class="no1"><a class="middle" href="#">Home</a></li>
                <li class="no1"><a class="middle" href="Profile.html">Profile</a></li>
                <li class="no1"><a class="middle" href="Product.html">Product</a></li>
                <li class="no1"><a class="middle" href="Contact_us.html">Contact Us</a></li>
                <form class="search-from">
                    <input type="text" placeholder="search">
                    <button class="search">search</button>
                </form>
            </ul>           
       </nav> 
       <div class="row">
        <div class="column side">

        </div>
        
        <div class="column middle">
          <h2 class="title1">Welcome to NEXT GEN</h2>
          <div class="slideshow-container">

            <div class="mySlides fade">
              <img src="images/nvidia-geforce-rtx2080-ti-new-graphic-card.jpeg" style="width:100%">
            </div>
            
            <div class="mySlides fade">
              <img src="images/geforce-gtx-1080.jpg" style="width:100%">
            </div>
            
            <div class="mySlides fade">
              <img src="images/maxresdefault (1).jpg" style="width:100%">
            </div>
            
            </div>
            <br>
            
            <div style="text-align:center">
              <span class="dot"></span> 
              <span class="dot"></span> 
              <span class="dot"></span> 
            </div>
        </div>
        
        <div class="column side">
          <h2 class="title1">OUR <br> BRANDS</h2>
          <table class="barnds1">
              <tr>
                <td><img class="brands" src="images/nvidia-quadro.jpg" alt="nvida"></td>
                <td><img class="brands" src="images/acer-logo.jpg" alt=acer"></td>
              </tr>
              <tr>
                  <td><img class="brands" src="images/intel-logo.png" alt="intel"></td>
                  <td><img class="brands" src="images/nzxt-logo.png" alt="nzxt"></td>
              </tr>
              <tr>
                  <td><img class="brands" src="images/zotac-1.jpg" alt="zotac"></td>
                  <td><img class="brands" src="images/hp.jpg" alt="hp"></td>
              </tr>
              <tr>
                  <td><img class="brands" src="images/seasonic-logo.png" alt="seasonic"></td>
                  <td><img class="brands" src="images/silverstone-1.jpg" alt="silverstone"></td></td>
              </tr>
          </table>
        </div>
      </div> 
        <hr>
        <center>
        <h3 class="offer" style="color: rgb(19, 110, 31);">OFFERS</h3>
        </center>
        <section class="features">
                <figure>
                    <a href="products/cpu/Intel_Core_i5-9600K.html">
                     <img src="images/19-117-959-V01-300x300.jpg"alt="bread"  style="width:70%">
                    </a> 
                     <figcaption>Intel Core i5-9600K</figcaption>
                </figure>
                <figure>
                     <img src="images/Intel-Core-i5-9400-300x300.jpg" alt="coffe"  style="width:70%"> 
                     <figcaption>Intel-Core-i5-9400-300x300</figcaption>
                </figure>
                <figure>
                     <img src="images/th-2-1.jpg" alt="coffe"  style="width:70%"> 
                     <figcaption>Intel-Core-i7</figcaption>
                </figure>
                <figure>
                    <img src="images/66op.jpg" alt="66op"  style="width:70%"> 
                    <figcaption>Intel 660P 512GB M.2</figcaption>
               </figure>
             </section>
        <hr>
    <footer>
        <ul>
            <li class="footer_icons1"><i class="fa fa-cc-paypal" style="font-size:40px"></i></li>
            <li class="footer_icons1"><i class="fa fa-cc-mastercard" style="font-size:40px"></i></li>
            <li class="footer_icons1"><i class="fa fa-cc-amex" style="font-size:40px"></i></li>
            <li class="footer_icons1"><i class="fa fa-cc-visa" style="font-size:40px"></i></li>
            <li class="footer_icons1"><h4 class="footer_text">Copyright2019 NextGen(pvt)Ltd.</h4></li>
        </ul>
       <ul>
           <li class="footer_icons2"><i class="fa fa-facebook-square" style="font-size:40px"></i></li>
           <li class="footer_icons2"><i class="fa fa-instagram" style="font-size:40px"></i></li>
           <li class="footer_icons2"><i class="fa fa-twitter" style="font-size:40px"></i></li>
       </ul>
            <p class="footer_para">Contact Us: <br> +94772341235 <br> Email Us: <br> NextGen@gmail.com</p>


    </footer>
</body>
<script src="js/slideShow.js"></script>
</html>